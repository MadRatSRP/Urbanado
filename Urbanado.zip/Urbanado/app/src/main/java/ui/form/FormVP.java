package ui.form;

public interface FormVP {
}
