package ui;

import android.content.Context;

public class RequestManager {
    /*private static RequestManager mRequestManager;
    private static RequestQueue mRequestQueue;*/
    // ImageLoader Instance

    private RequestManager() {

    }

    /*public static RequestManager get(Context context) {

        if (mRequestManager == null)
            mRequestManager = new RequestManager();

        return mRequestManager;
    }*/

    /*public static RequestQueue getnstance(Context context) {

        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(context);
        }

        return mRequestQueue;

    }*/


}